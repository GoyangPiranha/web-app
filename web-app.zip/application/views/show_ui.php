<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
        <title>Tampil UI Aja</title>
        <link href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css'); ?>" rel="stylesheet">
        <link href="<?php echo base_url('assets/bootstrap/css/style.css'); ?>" rel="stylesheet">

    </head>
    <body style="background: white;">
        <div class="container">
            <h4>List tampilan</h4>
            <ul class="list-group">
                <li class="list-group-item"><a href="<?=base_url(); ?>Login">Login</a></li>
                <li class="list-group-item"><a href="<?=base_url(); ?>Daftar">Register</a></li>
                <li class="list-group-item"><a href="<?=base_url(); ?>Home">Home</a></li>
                <li class="list-group-item"><a href="<?=base_url(); ?>">Profil-----------</a></li>
                <li class="list-group-item"><a href="<?=base_url(); ?>Detail/wishlist">Wishlist</a></li>
                <li class="list-group-item"><a href="<?=base_url(); ?>Konveksi_list">List Konveksi</a></li>
                <li class="list-group-item"><a href="<?=base_url(); ?>Profile_edit">Edit Profil</a></li>
                <li class="list-group-item"><a href="<?=base_url(); ?>Detail/sent_details">Detail Pengiriman</a></li>
                <li class="list-group-item"><a href="<?=base_url(); ?>Payment_method">Metode Pembayaran</a></li>
                <li class="list-group-item"><a href="<?=base_url(); ?>Purchasing_history">Rekap Pembelian</a></li>
                <li class="list-group-item"><a href="<?=base_url(); ?>Sell_history">Rekap Penjualan</a></li>
                <li class="list-group-item"><a href="<?=base_url(); ?>Detail/throwit">Throw It</a></li>
                <li class="list-group-item"><a href="<?=base_url(); ?>Detail">Detail Pembelian</a></li>
                <li class="list-group-item"><a href="<?=base_url(); ?>">Detail Penjualan</a></li>
                <li class="list-group-item"><a href="<?=base_url(); ?>Welcome">Maintenance</a></li>
            </ul>
        </div>
    </body>
</html>
