<html>
<?php foreach($konveksi as $row){
    echo $row->harga."------";
    echo $row->harga;
} ?>


</html>